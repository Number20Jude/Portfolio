<footer>
	© Copyright 2024. All rights reserved.
</footer>

<style>
	footer {
        color:white;
		padding-block: 5rem;
		background-color: black;
		text-align: center;
	}
</style>