<div>
    <h1>Travelling <span>Dog</span> Blog</h1>
    <p>Crates, toys, and treats for travelling dogs</p>
    <a href="/blog" class="button">Take a Look!</a>
</div>
<style>

div {
    
    padding-block: 16rem;
    padding-inline: 3rem;
    background-image: url('/caleb-fisher-pgUbpDLJh3E-unsplash.jpg');
    background-repeat: no-repeat;
    background-size:cover;
    border-radius: 0.9rem;
    text-shadow: 0 0 25px rgb(244, 236, 236);
}

h1{
    max-width: 42rem;
    margin: 0;
    font-size: 6rem;
    line-height: 1.1;
    text-shadow: 0 0 25px rgb(246, 239, 239);
}

span {
    color: hsl(34, 92%, 43%)
}
p{
    margin-block-start: 0.5rem;
    font-size: 1.5rem;
    text-transform: uppercase;
}

a{
    display: inline-block;
    margin-block-start: 1.5rem;
    padding-inline: 3rem;
}

a:hover {
    background-color: hsl(34, 92%, 43%);
    text-decoration: none;
}
</style>