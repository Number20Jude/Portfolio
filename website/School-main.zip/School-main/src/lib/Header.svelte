

<header >
	<div class ="container">
	
		<div class="logo">Travelling Dog</div>
		<nav>
			<ul>
				<li><a href = '/'>Home</li>
				<li><a href = '/blog'>Blog</li>
				<li><a href = '/contact'>Contact</li>
			</ul>
		</nav>
	</div>
</header>

<style>
	header {
		
		
		padding-block: 1.5rem;
		
		background-color:rosybrown;
		
		
	}
	.container{
		display: flex;
		justify-content: space-between;
		align-items: center;
		gap: 1.5rem;
	}
	
	
	.logo {
		color:rgb(99, 50, 50);
		font-size: 2rem;
		font-weight: bold;
	}
	
	
	ul {
		
		display: flex;
		gap: 2rem;
		list-style: none;
		margin: 0rem
	
	}

	
</style>